﻿
namespace SheriffMod
{
    public static class CustomGameOptions
    {
        public static bool showSheriff=false;
        public static float SheriffKillCD=25.0f;

    }
}
